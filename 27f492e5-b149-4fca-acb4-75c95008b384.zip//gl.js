const printArrayElements = (array) => {
  for (let i = 0; i < array.length; i++) {
    console.log(array[i]);
  }
};

const myArray = [1, 2, 3, 4, 5];
printArrayElements(myArray);
